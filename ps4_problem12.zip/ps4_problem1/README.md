## classes
1. player.Player
   <p> contains information and methods for a player.</p>
2. inning.Inning
    <p> contains information(total overs, wickets, score, etch..) about a inning</p>
3. utility.Utility
    <p>It contais realted actions or methods in a cricket inning, and some other related methods</p>  

## Please follow the steps to review this program.
1. Test cases are in test files.
2. Run playMatch.py and if you want to change inning setting you can 
change in playMatch.py file(like overs, runs, wickets and player's setting)
 
## Please provide feedback:- 
   <p>I am improving with every review. Thank you very much. I am really learning how to write good code.
    I need to improve. This is first time I have wrote testcases by myself.
     Anykind of suggestion will be more than welcome(I really mean it).
     Thank you. Have a nice day/night.</p>

### Edge_Case:
1. After a team gets all out, match can get tie. So I have handled this case.